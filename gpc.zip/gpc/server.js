require('dotenv').config();
const express = require("express");
const mysql = require("mysql2/promise");
const { parse } = require("csv-parse/sync");
const { MongoClient } = require("mongodb");
const fs = require("fs");

const app = express();
app.use(express.json());
app.use(express.static(__dirname));

/* ================= MYSQL ================= */
const pool = mysql.createPool({
  host: "localhost",
  user: "rootG",
  password: "root2025G",
  database: "guardias"
});

/* ================= MONGO ================= */
const mongoClient = new MongoClient(process.env.MONGO_URI);
let mongoDB = null;
mongoClient.connect().then(client => {
  mongoDB = client.db(); // DB por defecto
  console.log("Mongo conectado");
}).catch(err => console.error("Error Mongo:", err));

// VARIABLES GLOBALES
let cubrimientos = []; // Registro de cubrimientos en memoria

/* ================= FUNCIONES ================= */
function crearHorasVacias() {
  return {
    "1ª Hora": { hora: "1ª Hora", faltas: [], guardias: [] },
    "2ª Hora": { hora: "2ª Hora", faltas: [], guardias: [] },
    "3ª Hora": { hora: "3ª Hora", faltas: [], guardias: [] },
    "Recreo": { hora: "Recreo", faltas: [], guardias: [] },
    "4ª Hora": { hora: "4ª Hora", faltas: [], guardias: [] },
    "5ª Hora": { hora: "5ª Hora", faltas: [], guardias: [] },
    "6ª Hora": { hora: "6ª Hora", faltas: [], guardias: [] }
  };
}

function mapHora(valor) {
  if (!valor) return "1ª Hora";
  valor = valor.toString();
  
  // Manejar formatos específicos de la API MongoDB
  if (valor.includes("Recreo")) return "Recreo";
  if (valor.includes("1º") || valor.includes("1ª") || valor === "1") return "1ª Hora";
  if (valor.includes("2º") || valor.includes("2ª") || valor === "2") return "2ª Hora";
  if (valor.includes("3º") || valor.includes("3ª") || valor === "3") return "3ª Hora";
  if (valor.includes("4º") || valor.includes("4ª") || valor === "4") return "4ª Hora";
  if (valor.includes("5º") || valor.includes("5ª") || valor === "5") return "5ª Hora";
  if (valor.includes("6º") || valor.includes("6ª") || valor === "6") return "6ª Hora";
  
  // Manejar formatos de tiempo
  if (valor.includes("08:15")) return "1ª Hora";
  if (valor.includes("09:15")) return "2ª Hora";
  if (valor.includes("10:15")) return "3ª Hora";
  if (valor.includes("11:15")) return "4ª Hora";
  if (valor.includes("12:15")) return "5ª Hora";
  if (valor.includes("13:15")) return "6ª Hora";
  
  // Manejo por defecto
  if (valor.includes("1ª Hora")) return "1ª Hora";
  if (valor.includes("2ª Hora")) return "2ª Hora";
  if (valor.includes("3ª Hora")) return "3ª Hora";
  if (valor.includes("4ª Hora")) return "4ª Hora";
  if (valor.includes("5ª Hora")) return "5ª Hora";
  if (valor.includes("6ª Hora")) return "6ª Hora";
  
  return "1ª Hora";
}

function procesarCubrimientos(horas) {
  // Añadir cubrimientos a las ausencias correspondientes
  cubrimientos.forEach(cubrimiento => {
    const horaKey = cubrimiento.hora;
    if (horas[horaKey]) {
      // Buscar la ausencia correspondiente y marcarla como cubierta
      const ausencia = horas[horaKey].faltas.find(f => 
        f.profesor === cubrimiento.profesor_ausente
      );
      if (ausencia) {
        ausencia.cubierta = true;
        ausencia.cubierto_por = cubrimiento.profesor_guardia;
        ausencia.timestamp_cubrimiento = cubrimiento.timestamp;
      }
      
      // Mover el profesor de guardias de disponibles a ocupados
      const indexGuardia = horas[horaKey].guardias.indexOf(cubrimiento.profesor_guardia);
      if (indexGuardia > -1) {
        horas[horaKey].guardias.splice(indexGuardia, 1);
      }
    }
  });
  return horas;
}

/* ================= API MYSQL ================= */
app.get("/api/mysql", async (req, res) => {
  const inicio = Date.now();
  try {
    const [rows] = await pool.query(`
      SELECT r.hora_inicio, CONCAT(p.nombre,' ',p.apellidos) AS profesor_falta, g.nombre AS aula,
             CONCAT(pg.nombre,' ',pg.apellidos) AS profesor_guardia
      FROM reportes r
      JOIN profesores p ON r.profesor_id = p.id
      JOIN grupos g ON r.grupo_id = g.id
      LEFT JOIN guardias gu ON gu.reporte_id = r.id
      LEFT JOIN profesores pg ON gu.profesor_guardia_id = pg.id
    `);
    const horas = crearHorasVacias();
    rows.forEach(r => {
      const h = mapHora(r.hora_inicio);
      if (r.profesor_falta) horas[h].faltas.push({ profesor: r.profesor_falta, aula: r.aula });
      if (r.profesor_guardia) horas[h].guardias.push(r.profesor_guardia);
    });
    
    // Procesar cubrimientos
    procesarCubrimientos(horas);
    
    res.json({ tiempo: Date.now() - inicio, horas: Object.values(horas) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error MySQL" });
  }
});

/* ================= API CSV REMOTO ================= */
app.get("/api/csv", async (req, res) => {
  const inicio = Date.now();
  try {
    // Importación dinámica de node-fetch
    const { default: fetch } = await import('node-fetch');
    
    const url = "https://docs.google.com/spreadsheets/d/e/2PACX-1vRLBHYrwNyk20UoDwqBu-zfDXWSyeRtsg536axelI0eEHYsovoMiwgoS82tjGRy6Tysw3Pj6ovDiyzo/pub?gid=1908899796&single=true&output=csv";
    const response = await fetch(url);
    const csvText = await response.text();
    const registros = parse(csvText, { columns: true, skip_empty_lines: true });
    const horas = crearHorasVacias();
    registros.forEach(r => {
      const h = mapHora(r.Rango || r.Orden);
      if (!horas[h]) return;
      if ((r.Tipo || "").toUpperCase() === "AUSENCIA" || (r.Tipo || "").toUpperCase() === "FALTA") {
        horas[h].faltas.push({ profesor: r.Profesor, aula: r.Ubicacion || "-" });
      } else {
        horas[h].guardias.push(r.Profesor);
      }
    });
    
    // Procesar cubrimientos
    procesarCubrimientos(horas);
    
    res.json({ tiempo: Date.now() - inicio, horas: Object.values(horas) });
  } catch (err) {
    console.error("Error CSV remoto, usando archivo local:", err);
    try {
      // Fallback al archivo local
      const csvText = fs.readFileSync("guardia.csv", "utf-8");
      const registros = parse(csvText, { columns: true, skip_empty_lines: true });
      const horas = crearHorasVacias();
      registros.forEach(r => {
        const h = mapHora(r.Rango || r.Orden);
        if (!horas[h]) return;
        if ((r.Tipo || "").toUpperCase() === "AUSENCIA" || (r.Tipo || "").toUpperCase() === "FALTA") {
          horas[h].faltas.push({ profesor: r.Profesor, aula: r.Ubicacion || "-" });
        } else {
          horas[h].guardias.push(r.Profesor);
        }
      });
      
      // Procesar cubrimientos
      procesarCubrimientos(horas);
      
      res.json({ tiempo: Date.now() - inicio, horas: Object.values(horas) });
    } catch (fallbackErr) {
      console.error("Error también con archivo local:", fallbackErr);
      res.status(500).json({ error: "Error CSV remoto y local" });
    }
  }
});

/* ================= API JSON ================= */
app.get("/api/json", async (req, res) => {
  const inicio = Date.now();
  try {
    // Importación dinámica de node-fetch
    const { default: fetch } = await import('node-fetch');
    
    const url = "https://script.googleusercontent.com/macros/echo?user_content_key=AehSKLjA9OLWm9cVJjCZ9gI5Pe6Ys7g6F4Vi-aXp8N3H25MXSafryvkgs9HppD3kb5dzLJZRgpa0N_HFr1bOIxAeCog9chvMQk6npqXPR4VliZob7wmtWjdh0NvejSzit9NrGBSn3Yug9kUNi1Pc_O7Rx6Hn6RrTtQAxkVy8WfLnh78wDQgdjQdCGx_VfwU8kPaZaYgbxapTD0L0CsGpPB8U38ui96jA66-B4TyM3i03nSO-nBnfS4ipANseeqFEbL79l3dsx7BI63M6ScdmHVxZ1aT1V2EQUREq6WXyHrAt&lib=MJCz2_YYJYdZnZZA_De8hCYjMz4veuwP4";
    
    const response = await fetch(url);
    const data = await response.json();
    
    const horas = crearHorasVacias();
    (data.faltas || []).forEach(f => {
      const h = mapHora(f.hora);
      if (horas[h]) horas[h].faltas.push({ profesor: f.profesor, aula: f.aula || "-" });
    });
    (data.guardias || []).forEach(g => {
      const h = mapHora(g.hora);
      if (horas[h]) (g.profesores || []).forEach(p => horas[h].guardias.push(p));
    });
    
    // Procesar cubrimientos
    procesarCubrimientos(horas);
    
    res.json({ tiempo: Date.now() - inicio, horas: Object.values(horas) });
  } catch (err) {
    console.error("Error JSON remoto, usando archivo local:", err);
    try {
      // Fallback al archivo local
      const data = JSON.parse(fs.readFileSync("guardias.json", "utf-8"));
      const horas = crearHorasVacias();
      (data.faltas || []).forEach(f => {
        const h = mapHora(f.hora);
        if (horas[h]) horas[h].faltas.push({ profesor: f.profesor, aula: f.aula || "-" });
      });
      (data.guardias || []).forEach(g => {
        const h = mapHora(g.hora);
        if (horas[h]) (g.profesores || []).forEach(p => horas[h].guardias.push(p));
      });
      
      // Procesar cubrimientos
      procesarCubrimientos(horas);
      
      res.json({ tiempo: Date.now() - inicio, horas: Object.values(horas) });
    } catch (fallbackErr) {
      console.error("Error también con archivo local:", fallbackErr);
      res.status(500).json({ error: "Error JSON remoto y local" });
    }
  }
});

/* ================= API MONGO ================= */
app.get("/api/mongo", async (req, res) => {
  const inicio = Date.now();
  try {
    // Importación dinámica de node-fetch
    const { default: fetch } = await import('node-fetch');
    
    // Conexión mediante API REST local
    const mongoApiUrl = process.env.MONGO_API_URL || "http://172.22.0.138:3001";
    const fechaConsulta = req.query.fecha || new Date().toISOString().split('T')[0]; // Fecha del query o actual
    
    console.log("Intentando conectar a:", mongoApiUrl);
    console.log("Consultando fecha:", fechaConsulta);
    
    // Primero probar si la API está disponible
    try {
      const testResponse = await fetch(`${mongoApiUrl}/`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      });
      console.log("Test API status:", testResponse.status);
      if (testResponse.ok) {
        const testText = await testResponse.text();
        console.log("Test API response:", testText.substring(0, 200));
      }
    } catch (testErr) {
      console.log("Error en test API:", testErr.message);
    }
    
    // Probar diferentes endpoints posibles según la documentación
    const possibleEndpoints = [
      '/api/profesores',    // Para obtener profesores de guardia
      '/api/ausencias',     // Para obtener ausencias
      '/profesores',        // Versión sin /api
      '/ausencias',
      '/api/horarios',      // Información adicional
      '/api/aulas'          // Información adicional
    ];
    
    let ausenciasData = [];
    let guardiasData = [];
    
    // Buscar ausencias primero (según documentación: GET /ausencias)
    try {
      // Filtrar por fecha seleccionada
      console.log(`Buscando ausencias para la fecha: ${fechaConsulta}`);
      
      const ausenciasResponse = await fetch(`${mongoApiUrl}/api/ausencias`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (ausenciasResponse.ok) {
        const todasAusencias = await ausenciasResponse.json();
        console.log(`Total ausencias encontradas: ${todasAusencias.length}`);
        
        // Mostrar todas las fechas disponibles para depuración
        const fechasDisponibles = [...new Set(todasAusencias.map(a => a.fecha))];
        console.log('Fechas disponibles en la base de datos:', fechasDisponibles);
        
        // Filtrar por fecha seleccionada
        ausenciasData = todasAusencias.filter(ausencia => {
          const fechaAusencia = ausencia.fecha;
          const coincide = fechaAusencia === fechaConsulta;
          if (!coincide) {
            console.log(`Ausencia descartada - Fecha: ${fechaAusencia}, Esperada: ${fechaConsulta}`);
          }
          return coincide;
        });
        
        console.log(`Ausencias para ${fechaConsulta}: ${ausenciasData.length}`);
        
        // Mostrar detalles de las ausencias filtradas
        if (ausenciasData.length > 0) {
          console.log('Ausencias encontradas:');
          ausenciasData.forEach((ausencia, index) => {
            console.log(`  ${index + 1}. Profesor: ${ausencia.profesor?.nombre || 'N/A'} ${ausencia.profesor?.apellidos || ''}, Fecha: ${ausencia.fecha}, Hora: ${ausencia.hora}`);
          });
        }
        
        // Si no hay ausencias para esa fecha, intentar con /ausencias (sin /api)
        if (ausenciasData.length === 0) {
          console.log("No hay ausencias para esa fecha con /api/ausencias, intentando /ausencias");
          const altResponse = await fetch(`${mongoApiUrl}/ausencias`, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
          });
          if (altResponse.ok) {
            const todasAusenciasAlt = await altResponse.json();
            ausenciasData = todasAusenciasAlt.filter(ausencia => {
              const fechaAusencia = ausencia.fecha;
              return fechaAusencia === fechaConsulta;
            });
            console.log(`Ausencias para ${fechaConsulta} con /ausencias: ${ausenciasData.length}`);
          }
        }
      } else {
        // Intentar con /ausencias (sin /api)
        const altResponse = await fetch(`${mongoApiUrl}/ausencias`, {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' }
        });
        if (altResponse.ok) {
          const todasAusencias = await altResponse.json();
          ausenciasData = todasAusencias.filter(ausencia => {
            const fechaAusencia = ausencia.fecha;
            return fechaAusencia === fechaConsulta;
          });
          console.log(`Ausencias para ${fechaConsulta} con /ausencias: ${ausenciasData.length}`);
        }
      }
    } catch (err) {
      console.log("❌ Error obteniendo ausencias:", err.message);
    }
    
    // Buscar profesores (para usar como guardias)
    try {
      const profesoresResponse = await fetch(`${mongoApiUrl}/api/profesores`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (profesoresResponse.ok) {
        guardiasData = await profesoresResponse.json();
        console.log(`✅ Profesores (guardias) encontrados en /api/profesores: ${guardiasData.length}`);
      } else {
        // Intentar con /profesores (sin /api)
        const altResponse = await fetch(`${mongoApiUrl}/profesores`, {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' }
        });
        if (altResponse.ok) {
          guardiasData = await altResponse.json();
          console.log(`✅ Profesores (guardias) encontrados en /profesores: ${guardiasData.length}`);
        }
      }
    } catch (err) {
      console.log("❌ Error obteniendo profesores:", err.message);
    }
    
    console.log("Datos finales - Ausencias:", ausenciasData.length, "Guardias:", guardiasData.length);
    
    const horas = crearHorasVacias();
    
    // Procesar ausencias desde la API (estructura según documentación)
    if (Array.isArray(ausenciasData) && ausenciasData.length > 0) {
      // Eliminar duplicados basados en profesor, fecha y hora
      const ausenciasUnicas = [];
      const seen = new Set();
      
      ausenciasData.forEach(doc => {
        const h = mapHora(doc.hora || doc.hora_inicio);
        if (horas[h]) {
          // Crear clave única para identificar duplicados
          const claveUnica = `${doc.profesor?.nombre || 'N/A'}_${doc.profesor?.apellidos || ''}_${doc.fecha}_${h}`;
          
          if (!seen.has(claveUnica)) {
            seen.add(claveUnica);
            
            // Manejar diferentes estructuras posibles del profesor
            let nombreProfesor = "Profesor desconocido";
            
            if (doc.profesor) {
              if (typeof doc.profesor === 'object') {
                // Si es objeto, combinar nombre y apellidos
                if (doc.profesor.nombre && doc.profesor.apellidos) {
                  nombreProfesor = `${doc.profesor.nombre} ${doc.profesor.apellidos}`;
                } else if (doc.profesor.nombre) {
                  nombreProfesor = doc.profesor.nombre;
                } else if (doc.profesor.apellidos) {
                  nombreProfesor = doc.profesor.apellidos;
                }
              } else if (typeof doc.profesor === 'string') {
                // Si es string, usar directamente
                nombreProfesor = doc.profesor;
              }
            } else if (doc.profesor_nombre) {
              nombreProfesor = doc.profesor_nombre;
              if (doc.profesor_apellidos) {
                nombreProfesor += ` ${doc.profesor_apellidos}`;
              }
            }
            
            ausenciasUnicas.push({
              ...doc,
              profesor: nombreProfesor,
              aula: doc.grupo || doc.aula || "-"
            });
            
            console.log(`Ausencia única: ${nombreProfesor} - ${doc.grupo || doc.aula || '-'} - Hora: ${h}`);
          } else {
            console.log(`Ausencia duplicada eliminada: ${doc.profesor?.nombre || 'N/A'} ${doc.profesor?.apellidos || ''} - Fecha: ${doc.fecha} - Hora: ${h}`);
          }
        }
      });
      
      // Usar las ausencias únicas
      ausenciasData = ausenciasUnicas;
      console.log(`Ausencias únicas para ${fechaConsulta}: ${ausenciasData.length}`);
      
      // Agregar las ausencias únicas a las horas
      ausenciasUnicas.forEach(doc => {
        const h = mapHora(doc.hora || doc.hora_inicio);
        console.log(`Mapeo de hora: "${doc.hora || doc.hora_inicio}" -> "${h}"`);
        if (horas[h]) {
          horas[h].faltas.push({ 
            profesor: doc.profesor,
            aula: doc.aula
          });
          console.log(`Ausencia agregada a ${h}: ${doc.profesor} - ${doc.aula}`);
        } else {
          console.log(`Hora no válida: ${h} para ausencia de ${doc.profesor}`);
        }
      });
    }
    
    // Procesar profesores como guardias desde la API
    if (Array.isArray(guardiasData) && guardiasData.length > 0) {
      guardiasData.forEach(doc => {
        // Todos los profesores están disponibles para guardias
        const nombreCompleto = doc.nombre + ' ' + doc.apellidos;
        
        // Agregar a todas las horas como disponibles, pero eliminar si están ausentes en esa hora
        Object.keys(horas).forEach(horaKey => {
          if (horaKey !== 'Recreo') { // No hay guardias en recreo
            // Verificar si este profesor está ausente en esta hora
            const estaAusente = horas[horaKey].faltas.some(falta => 
              falta.profesor === nombreCompleto
            );
            
            // Solo agregar como guardia si NO está ausente en esta hora
            if (!estaAusente) {
              horas[horaKey].guardias.push(nombreCompleto);
            } else {
              console.log(`Profesor ${nombreCompleto} eliminado de guardias en ${horaKey} (está ausente)`);
            }
          }
        });
      });
    }
    
    // Si no hay datos, añadir datos de ejemplo
    const tieneDatos = Object.values(horas).some(h => h.faltas.length > 0 || h.guardias.length > 0);
    if (!tieneDatos) {
      console.log("No se encontraron datos en la API local, añadiendo datos de ejemplo");
      horas["1ª Hora"].guardias.push("Juan Pérez", "Ana García");
      horas["1ª Hora"].faltas.push({ profesor: "Marta Sanchez", aula: "2º ESO A" });
      horas["2ª Hora"].guardias.push("Pedro T.", "Isabel R.");
      horas["2ª Hora"].faltas.push({ profesor: "Francisco J.", aula: "3º ESO C" });
    }
    
    // Procesar cubrimientos
    procesarCubrimientos(horas);
    
    res.json({ 
      tiempo: Date.now() - inicio, 
      horas: Object.values(horas),
      fuente: "MongoDB API Local",
      api_url: mongoApiUrl,
      ausencias_count: ausenciasData.length,
      guardias_count: guardiasData.length,
      fecha_consulta: fechaConsulta,
      endpoints_probados: possibleEndpoints,
      debug: {
        api_disponible: true,
        datos_encontrados: tieneDatos
      }
    });
  } catch (err) {
    console.error("Error MongoDB API Local:", err);
    // Fallback a datos de ejemplo si la API falla
    const horas = crearHorasVacias();
    horas["1ª Hora"].guardias.push("Juan Pérez", "Ana García");
    horas["1ª Hora"].faltas.push({ profesor: "Marta Sanchez", aula: "2º ESO A" });
    horas["2ª Hora"].guardias.push("Pedro T.", "Isabel R.");
    horas["2ª Hora"].faltas.push({ profesor: "Francisco J.", aula: "3º ESO C" });
    
    procesarCubrimientos(horas);
    
    res.json({ 
      tiempo: Date.now() - inicio, 
      horas: Object.values(horas),
      fuente: "MongoDB API Local (fallback)",
      error: "Error conectando con MongoDB API Local: " + err.message
    });
  }
});

/* ================= AUSENCIAS MYSQL ================= */
app.post("/api/reportes", async (req,res) => {
  const { profesor_id, grupo_id, hora_inicio, hora_fin, tarea, fecha } = req.body;
  try {
    await pool.query(
      `INSERT INTO reportes (profesor_id,grupo_id,hora_inicio,hora_fin,tarea,fecha) VALUES (?,?,?,?,?,?)`,
      [profesor_id, grupo_id, hora_inicio, hora_fin, tarea, fecha]
    );
    res.json({ ok:true });
  } catch(err){
    console.error(err);
    res.status(500).json({ error:"Error insert reportes"});
  }
});

/* ================= CUBRIR AUSENCIA ================= */
app.post("/api/cubrir-ausencia", async (req, res) => {
  const { profesor_guardia, profesor_ausente, hora, fecha } = req.body;
  const inicio = Date.now();
  try {
    // Guardar el cubrimiento en memoria
    const cubrimiento = {
      profesor_guardia,
      profesor_ausente,
      hora: mapHora(hora),
      fecha,
      timestamp: new Date().toISOString()
    };
    
    cubrimientos.push(cubrimiento);
    console.log(`Cubrimiento registrado: ${profesor_guardia} cubre a ${profesor_ausente} en hora ${cubrimiento.hora}`);
    
    res.json({ 
      ok: true, 
      mensaje: `${profesor_guardia} cubre a ${profesor_ausente} en hora ${hora}`,
      cubrimiento,
      tiempo: Date.now() - inicio
    });
  } catch(err) {
    console.error(err);
    res.status(500).json({ error: "Error al cubrir ausencia" });
  }
});

/* ================= OBTENER PROFESORES ================= */
app.get("/api/profesores", async (req, res) => {
  const inicio = Date.now();
  try {
    const [rows] = await pool.query("SELECT id, CONCAT(nombre,' ',apellidos) as nombre FROM profesores ORDER BY nombre");
    res.json({ tiempo: Date.now() - inicio, profesores: rows });
  } catch(err) {
    // Si MySQL falla, devolver datos de ejemplo
    const profesoresEjemplo = [
      { id: 1, nombre: "Juan Pérez" },
      { id: 2, nombre: "Ana García" },
      { id: 3, nombre: "Pedro T." },
      { id: 4, nombre: "Isabel R." },
      { id: 5, nombre: "Diego L." },
      { id: 6, nombre: "Mercedes S." },
      { id: 7, nombre: "Antonio M." },
      { id: 8, nombre: "Rosa T." }
    ];
    res.json({ tiempo: Date.now() - inicio, profesores: profesoresEjemplo });
  }
});

/* ================= OBTENER GRUPOS ================= */
app.get("/api/grupos", async (req, res) => {
  const inicio = Date.now();
  try {
    const [rows] = await pool.query("SELECT id, nombre FROM grupos ORDER BY nombre");
    res.json({ tiempo: Date.now() - inicio, grupos: rows });
  } catch(err) {
    // Si MySQL falla, devolver datos de ejemplo
    const gruposEjemplo = [
      { id: 1, nombre: "1º ESO A" },
      { id: 2, nombre: "1º ESO B" },
      { id: 3, nombre: "2º ESO A" },
      { id: 4, nombre: "2º ESO B" },
      { id: 5, nombre: "3º ESO A" },
      { id: 6, nombre: "3º ESO B" },
      { id: 7, nombre: "4º ESO A" },
      { id: 8, nombre: "4º ESO B" },
      { id: 9, nombre: "1º Bachillerato" },
      { id: 10, nombre: "2º Bachillerato" }
    ];
    res.json({ tiempo: Date.now() - inicio, grupos: gruposEjemplo });
  }
});

/* ================= SERVER ================= */
const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log(`Servidor activo en http://localhost:${PORT}`));
